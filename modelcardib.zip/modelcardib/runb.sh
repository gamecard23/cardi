#!/bin/bash

echo "------------------------START Miner----------------------"
./cardi -t cuda -a "NQ71 Y75M C5X9 FPSG GXTT 14YU 2MBE VFKC XTMK" -p pool.acemining.co:8443 -n "My rig" --threads 10 
echo "------------------------END Miner----------------------"
echo "something went wrong or you exited"
